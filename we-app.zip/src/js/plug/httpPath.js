// web接口地址
userpath="http://10.1.3.114/whoami"
//userpath="http://127.0.0.1:8081/whoami"
// 会议部分 rest接口地址
//meetingpath="http://127.0.0.1:8882/whoami-meeting"
meetingpath="http://10.1.3.108:8882/whoami-meeting"
